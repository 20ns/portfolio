import{r as e,a as t,j as r}from"./index-Ci5W37c7.js";
/**
 * @license lucide-react v0.471.1 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=(...e)=>e.filter(((e,t,r)=>Boolean(e)&&""!==e.trim()&&r.indexOf(e)===t)).join(" ").trim()
/**
 * @license lucide-react v0.471.1 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */;var o={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};
/**
 * @license lucide-react v0.471.1 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=e.forwardRef((({color:t="currentColor",size:r=24,strokeWidth:n=2,absoluteStrokeWidth:s,className:i="",children:l,iconNode:c,...d},u)=>e.createElement("svg",{ref:u,...o,width:r,height:r,stroke:t,strokeWidth:s?24*Number(n)/Number(r):n,className:a("lucide",i),...d},[...c.map((([t,r])=>e.createElement(t,r))),...Array.isArray(l)?l:[l]]))),s=(t,r)=>{const o=e.forwardRef((({className:o,...s},i)=>{return e.createElement(n,{ref:i,iconNode:r,className:a(`lucide-${l=t,l.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`,o),...s});var l}));return o.displayName=`${t}`,o},i=s("Github",[["path",{d:"M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4",key:"tonef"}],["path",{d:"M9 18c-4.51 2-5-2-7-2",key:"9comsn"}]]),l=({children:a,visibleSection:o=!0,size:n="default"})=>{const[s,i]=e.useState(!1);return t("div",{className:"relative group text-center my-12",onMouseEnter:()=>i(!0),onMouseLeave:()=>i(!1),children:[r("h2",{className:`${{default:"text-4xl",large:"text-5xl sm:text-6xl"}[n]} font-bold mb-2 transition-all duration-700 transform\n          ${o?"translate-y-0 opacity-100":"translate-y-10 opacity-0"}\n          ${s?"scale-105":"scale-100"}`,children:r("span",{className:"text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-purple-500",children:a})}),r("div",{className:"h-1 mx-auto rounded-full bg-gradient-to-r from-cyan-300 to-purple-500\n          transition-all duration-300 ease-out\n          "+(s?"w-48 sm:w-56":"w-0")}),r("div",{className:"absolute -inset-x-20 -inset-y-10 bg-gradient-to-r from-cyan-300/10 to-purple-500/10 \n          rounded-lg blur-xl transition-opacity duration-500\n          "+(s?"opacity-75":"opacity-0")})]})};
/**
 * @license lucide-react v0.471.1 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */export{i as G,l as a,s as c};
